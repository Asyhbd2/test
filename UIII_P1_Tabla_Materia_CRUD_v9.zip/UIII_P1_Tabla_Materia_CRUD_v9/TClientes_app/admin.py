from django.contrib import admin
from .models import TCliente
# Register your models here.

admin.site.register(TCliente)