from django.contrib import admin
from .models import TProducto
# Register your models here.

admin.site.register(TProducto)