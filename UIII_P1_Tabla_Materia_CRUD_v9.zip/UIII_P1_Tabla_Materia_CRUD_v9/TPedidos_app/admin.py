from django.contrib import admin
from .models import TPedido
# Register your models here.

admin.site.register(TPedido)